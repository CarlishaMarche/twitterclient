package org.tejen.codepathandroid.twitter.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by tejen on 7/3/17.
 */

public class SimpleNavigationDrawerFragment extends Fragment {
}
